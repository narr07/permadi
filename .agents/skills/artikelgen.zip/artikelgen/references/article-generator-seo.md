# Panduan Penulisan Artikel & SEO Berbasis Google Trends (Article Generator)

Panduan operasional lengkap untuk meriset tren pencarian pengguna, menyusun strategi kata kunci, dan menghasilkan artikel blog berkualitas tinggi yang **100% terasa seperti tulisan praktisi manusia asli**, bebas dari pola klise AI, dan mendominasi SERP Google dengan format native Nuxt Content.

---

## 0. STANDAR PENULISAN MANUSIAWI (ANTI-AI WRITING PROTOCOL)

Artikel yang diproduksi **HARUS LOLOS UJI RASA MANUSIA (HUMAN SME FEEL)**. Pembaca tidak boleh merasa sedang membaca teks yang digenerate oleh AI.

### A. Daftar Hitam Frasa Klise AI (BANNED PHRASES)

| Kategori | ❌ Frasa Terlarang (Bahasa Indonesia) | ❌ Frasa Terlarang (Bahasa Inggris) | Alternatif Penulisan Praktisi |
| :--- | :--- | :--- | :--- |
| **Pembuka Klise** | *"Dalam era digital...", "Di tengah pesatnya perkembangan...", "Perkembangan teknologi telah membawa..."* | *"In today's fast-paced digital world...", "In the ever-evolving landscape...", "In recent years..."* | Langsung tembak masalah inti, paradoks, atau fakta riil di lapangan. |
| **Basa-Basi & Meta-Talk** | *"Mari kita selami...", "Perlu diingat bahwa...", "Tidak dapat dipungkiri bahwa...", "Patut dicatat..."* | *"Let's delve into...", "Dive deep into...", "It is important to note that...", "Needless to say..."* | Hapus seluruh basa-basi. Nyatakan poin atau data secara langsung. |
| **Hiperbola Kosong** | *"Solusi revolusioner", "Game changer", "Tonggak penting", "Transformasi fundamental"* | *"Game-changer", "Revolutionize", "Tapestry", "Beacon", "Crucial role", "Harness the power"* | Sebutkan angka/efek spesifik (*"memangkas latensi 40ms"*). |
| **Transisi Kaku** | *"Selain itu,", "Di samping itu,", "Lebih lanjut,", "Oleh karena itu,"* (di awal setiap paragraf) | *"Furthermore,", "Moreover,", "In addition,", "Additionally,"* | Gunakan transisi percakapan atau alur sebab-akibat alami. |
| **Penutup Klise** | *"Secara keseluruhan...", "Dapat disimpulkan bahwa...", "Sebagai penutup...", "Kesimpulannya..."* | *"In conclusion,", "To sum up,", "All in all,", "In summary..."* | Sajikan **Panduan Keputusan (*Decision Matrix*)** praktis. |

---

### B. Dinamika Ritme & Variasi Kalimat (*Burstiness*)
* **Kalimat Ultra-Pendek (1–5 kata)**: Sisipkan untuk memberi jeda dramatis, pukulan logika, atau ketegasan (*"Hasilnya? Nihil."*, *"Kenyataannya tidak demikian."*).
* **Kalimat Sedang (10–18 kata)**: Untuk penjelasan lugas instruksional.
* **Kalimat Panjang (20–35 kata)**: Untuk menjelaskan logika bersyarat, hubungan sebab-akibat, atau analogi detail.
* **Struktur Paragraf Dinamis**: Jangan pernah membuat semua paragraf setinggi 3 kalimat. Selingi dengan paragraf 1 kalimat tunggal untuk penekanan.

---

### C. Sentuhan Praktisi & Kompromi Lapangan (*Real-World Friction & Trade-offs*)
* **Bongkar Mitos & Kesalahan Umum**: Jelaskan kesalahan konyol yang sering dilakukan pemula atau praktisi di lapangan.
* **Ungkapkan Sisi Negatif / Batasan (*Trade-offs*)**: Tidak ada solusi ajaib yang sempurna. Setiap pilihan teknologi/metode punya kelemahan. Sebutkan kelemahan itu dengan jujur.
* **Gunakan Sudut Pandang Tegas (*Have a Stance*)**: Jangan abu-abu atau sekadar merangkum Wikipedia. Berikan rekomendasi berani kapan harus memakai solusi A dan kapan harus menghindari solusi B.

---

## 1. Tahap 0: Riset Tren Google (Pre-Writing Intelligence)

Sebelum menulis draf, lakukan analisis tren pencarian real-time untuk memvalidasi sudut pandang artikel:

### Langkah Riset Tren (Native Gemini Spark / Grounded Search):
1. **Identifikasi Kueri Lonjakan (*Rising / Breakout Queries*)**:
   - Telusuri lonjakan topik dan istilah pencarian yang sedang melonjak di Google Trends Indonesia (`geo: ID`).
2. **Kumpulkan Pola Pertanyaan Populer**:
   - Analisis *People Also Ask* dan saran *Autocomplete* Google seputar kata kunci utama.
3. **Analisis Kebutuhan Konten (*Search Intent Mapping*)**:
   - Pastikan apakah pengguna mencari tutorial langkah-demi-langkah (*informational*), perbandingan mendalam (*commercial investigation*), atau solusi instan (*transactional*).

### Cara Memanfaatkan Data Google Trends ke Dalam Konten:
1. **Saran Sudut Pandang (Angle Recommendation)**: Berikan ringkasan singkat 2–3 poin rekomendasi tren kepada pengguna sebelum blok kode artikel.
2. **Optimasi Judul & H1**: Masukkan kata kunci/frasa yang memiliki volume pencarian tinggi atau sedang *breakout*.
3. **Subtopik (H2/H3)**: Jadikan *related queries* sebagai subjudul (`##` atau `###`) agar artikel langsung menjawab pertanyaan spesifik pembaca.
4. **FAQ Accordion**: Ambil pertanyaan yang sering muncul dari saran *autocomplete* untuk dijadikan butir FAQ.

---

## 2. Alur Kerja Sebelum Menulis (Pre-Writing Intake)

Pastikan 5 parameter kunci berikut telah terdefinisi:
1. **Topik & Kata Kunci Utama (Primary Keyword)**: Divalidasi dengan Google Trends.
2. **Kata Kunci Turunan / LSI (Secondary Keywords)**: Dari hasil kueri penelusuran terkait.
3. **Target Audiens** (mis. pemula/awam, desainer, guru/pendidik, pengembang, pemilik bisnis).
4. **Search Intent**:
   - *Informational*: Fokus edukasi komprehensif, solusi langkah-demi-langkah.
   - *Commercial Investigation*: Perbandingan fitur, kelebihan/kekurangan, panduan memilih.
   - *Transactional*: Rekomendasi tindakan langsung, implementasi alat/solusi.
5. **Gaya Bahasa / Brand Voice**: Tajam, praktis, mengalir seperti obrolan profesional senior, bebas dari jargon kosong.

> *Catatan & Aturan Mutlak Output*: 
> Setiap kali pengguna meminta pembuatan artikel, Anda **WAJIB LANGSUNG MENGHASILKAN 2 BLOK KODE `.md` LENGKAP** (Versi Bahasa Indonesia `content/id/blog/...` dan Versi Bahasa Inggris `content/en/blog/...`) yang siap disalin langsung (*copy-paste ready*) beserta saran nama file dan prompt gambar brand. Tidak perlu menunggu pengguna meminta terjemahan secara terpisah.

---

## 3. Standar Tata Bahasa & Keterbacaan Humanis

### Pola Kalimat & Voice
- **Kalimat Aktif Dominan**: Subjek melakukan aksi nyata. Hindari struktur kalimat pasif yang lelah dibaca.
- **Waktu Kini (Present Tense)**: Untuk instruksi teknis dan fakta ilmiah.
- **Kombinasi Gaya Pembuka**:
  - *Langsung Objek/Aksi (~50%)*: "Format OTF menyimpan ribuan karakter ekstra."
  - *Kondisional / Skenario (~30%)*: "Saat Anda mengajar di kelas 35 anak, metode diskusi murni akan gagal."
  - *Tanya/Retoris (~20%)*: "Mengapa modul ajar yang dirancang berjam-jam tetap gagal menarik antusiasme siswa?"

---

## 4. Master Checklist 9 Tahap Penulisan & SEO On-Page (Lengkap)

### Tahap 1: Perencanaan Strategis & Kalender Editorial
- [ ] **Batching Riset Kata Kunci**: Riset kelompok kata kunci volume vs kesulitan (KD).
- [ ] **Penyelarasan Buyer Persona**: Jawab pertanyaan spesifik dan *pain points* nyata.
- [ ] **Evaluasi Otoritas Topikal (Topic Clusters)**: Bangun gugus topik yang saling berkaitan.

### Tahap 2: Arsitektur Metadata & Optimasi On-Page
- [ ] **Optimasi Judul SEO (Title Tag)**: Maksimal 60 karakter, kata kunci utama di depan, mengandung proposisi nilai riil.
- [ ] **Penyelarasan H1 dan Title Tag**: Wajib identik atau sangat mirip. Tidak ada backtick di H1.
- [ ] **Penulisan Meta Deskripsi**: 140–160 karakter persuasif, to-the-point, mengandung kata kunci utama.
- [ ] **Struktur URL Slug Bersih**: Huruf kecil, dipisah tanda hubung (`-`), fokus pada kata kunci inti.

### Tahap 3: Pendahuluan (The Problem Hook & Benefit)
- [ ] **Tembak Akar Masalah Langsung**: Bongkar friksi/kesulitan nyata dalam 100 kata pertama bersama kata kunci utama.
- [ ] **Tanpa Basa-Basi**: Dilarang memakai *"Di era modern..."* atau *"Pada artikel kali ini kita akan membahas..."*.

### Tahap 4: Keterbacaan (Readability) & Struktur Humanis
- [ ] **Variasi Panjang Paragraf & Kalimat**: Wajib padukan kalimat 3 kata dengan kalimat 25 kata.
- [ ] **Heading Hierarkis (`##` H2, `###` H3, `####` H4)**: Struktur logis yang mengalir natural.
- [ ] **Elemen MDC Komponen**: Gunakan `::steps`, `::tip`, `::note`, `::warning`, dan `::conclusion`.

### Tahap 5: Kedalaman Substansi & Sentuhan Praktisi (E-E-A-T)
- [ ] **Kedalaman Konten (1.500–2.000+ Kata)**: Komprehensif tanpa pengulangan kata berputar-putar.
- [ ] **Studi Kasus & Trade-offs**: Wajib sertakan kompromi atau konsekuensi dari tiap pilihan.
- [ ] **Content Gap**: Tutup celah informasi yang dilewatkan oleh hasil pencarian kompetitor.

### Tahap 6: Optimasi Visual & Multimedia
- [ ] **Format Next-Gen (WebP)**: Path gambar `/article/nama-file.webp`.
- [ ] **Alt Text Deskriptif**: Maksimal 125 karakter, kontekstual.
- [ ] **Tabel Markdown**: Gunakan tabel untuk komparasi head-to-head.

### Tahap 7: Strategi Tautan (Internal & External Linking)
- [ ] **Internal Linking**: Minimal 2–3 tautan ke artikel relevan (`[teks](/blog/slug-terkait)`).
- [ ] **External Linking**: Minimal 2–3 tautan ke dokumentasi resmi atau riset otoritas.

### Tahap 8: Penutup & Action Framework
- [ ] **Kesimpulan Keputusan (`::conclusion`)**: Berikan panduan kapan harus memilih Opsi A vs Opsi B.
- [ ] **Satu Tindakan Spesifik**: Arahkan ke langkah nyata berikutnya.

### Tahap 9: Penyuntingan Anti-AI & Finalisasi
- [ ] **Uji Baca Nyaring**: Pastikan ritme tidak kaku dan tidak terdengar seperti naskah terjemahan robot.
- [ ] **Cek Blacklist Frasa**: Pastikan 0 kata dari daftar hitam AI muncul di draf.

---

## 5. Template Struktur Artikel Siap Terbit

````md
---
title: "Judul Tajam dengan Primary Keyword: Subjudul Solutif Praktisi"
category: kategori-blog
date: YYYY-MM-DD
description: Deskripsi 140-160 karakter memuat primary keyword, to the point, dan memicu rasa ingin tahu tanpa basa-basi klise.
tags:
  - tag-utama
  - tag-pendukung
---

## Masalah Riil yang Kerap Terjadi di Lapangan

Paragraf pembuka langsung membongkar akar masalah atau paradoks yang dihadapi pembaca. Kata kunci utama disisipkan secara natural dalam 100 kata pertama tanpa kalimat pembuka klise.

Jelaskan mengapa pendekatan konvensional kerap kali gagal dan apa konsekuensi langsungnya jika salah mengambil keputusan.

![Deskripsi visual ilustrasi kontekstual](/article/nama-gambar.webp)

## Poin Utama Pertama: Realita vs Ekspektasi Teori

Jelaskan konsep dengan analogi segar dan contoh nyata di lapangan.

- **Faktor Kunci 1**: Penjelasan spesifik beserta kompromi teknisnya.
- **Faktor Kunci 2**: Langkah praktis yang teruji.

::tip
Berikan catatan taktis dari pengalaman praktisi yang bisa langsung menyelamatkan waktu atau anggaran pembaca.
::

## Poin Utama Kedua: Prosedur Eksekusi Bertahap

::steps
### Siapkan Parameter Kunci
Langkah awal tanpa nomor di heading.

### Terapkan Konfigurasi Inti
Eksekusi tindakan utama dengan parameter yang sudah diuji.
::

## Poin Utama Ketiga: Komparasi dan Trade-offs Nyata

Bandingkan opsi-opsi yang ada secara jujur beserta kelemahan masing-masing dalam tabel:

| Opsi / Metode | Keunggulan Utama | Kelemahan / Risiko | Skenario Ideal |
| :--- | :--- | :--- | :--- |
| **Pilihan A** | Cepat, implementasi mudah | Boros resource di skala besar | Proyek awal / tim kecil |
| **Pilihan B** | Sangat skalabel & stabil | Kurva belajar curam | Sistem produksi enterprise |

::conclusion
Panduan keputusan akhir berdasarkan kebutuhan riil Anda:

- **Pilih Pendekatan A**: Jika Anda membutuhkan kecepatan dan kemudahan penerapan segera.
- **Pilih Pendekatan B**: Jika stabilitas jangka panjang dan skalabilitas adalah prioritas absolut.
::

::faq
::faq-item{question="Pertanyaan pertama yang paling sering dicari di Google?"}
Jawaban lugas 2–4 kalimat yang langsung menjawab inti keraguan tanpa berputar-putar.
::

::faq-item{question="Apa kesalahan paling fatal yang sering dilakukan pemula?"}
Penjelasan ringkas mengenai pitfall umum dan cara menghindarinya sejak hari pertama.
::
::
````
